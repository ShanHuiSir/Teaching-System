package com.teachingeval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class TeachingSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(TeachingSystemApplication.class, args);
    }
}

